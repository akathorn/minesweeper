from pytest_mock import mocker, MockerFixture  # type: ignore


def test_1(mocker: MockerFixture):
    assert True
