class Game:
    def __init__(self) -> None:
        self.state = 3

    def action(self):
        self.state += 1